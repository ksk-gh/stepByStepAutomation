package com.salesforce.pages;

import org.testng.Assert;

import com.salesforce.base.ProjectSpecificMethods;

public class OpportunityPage extends ProjectSpecificMethods {

	public OpportunityPage clickNewButton() {

		// driver.findElement(By.xpath(prop.getProperty("opportunities.newbtn.xpath"))).click();

		click(locateElement("xpath", prop.getProperty("opportunities.newbtn.xpath")));
		return this;

	}

	public OpportunityPage enterOpportunityName(String enterOpportunity) {
		/*
		 * driver.findElement(By.xpath(prop.getProperty(
		 * "opportunities.opportunityname.xpath"))) .sendKeys(enterOpportunity);
		 */
		type(locateElement("xpath", prop.getProperty("opportunities.opportunityname.xpath")), enterOpportunity);
		return this;

	}

	public OpportunityPage getEnteredOpportunityName() {
		/*
		 * String opportunityValue = driver.findElement(By.xpath(prop.getProperty(
		 * "opportunities.opportunityname.xpath"))) .getAttribute("value");
		 */

		getEnteredText(locateElement("xpath", prop.getProperty("opportunities.opportunityname.xpath")));
		return this;
	}

	public OpportunityPage clickCloseDate() {

		clickUsingJs(locateElement("xpath", prop.getProperty("opportunities.closedate.xpath")));

		return this;
	}

	public OpportunityPage clickTodayDateNumber() {
		click(locateElement("xpath", prop.getProperty("opportunities.todaydatenumber.xpath")));
		return this;

	}

	public OpportunityPage clickNextDay() {
		// driver.findElement(By.xpath(prop.getProperty("opportunities.nextdate.xpath"))).click();
		click(locateElement("xpath", prop.getProperty("opportunities.nextdate.xpath")));

		return this;

	}

	public OpportunityPage clickStageDropdown() {

		click(locateElement("xpath", prop.getProperty("opportunities.stagedropdown.xpath")));
		return this;

	}

	public OpportunityPage selectNeedAnalaysisValue() {

		click(locateElement("xpath", prop.getProperty("opportunities.stagevalueNeedanalysis.xpath")));

		return this;
	}

	public OpportunityPage selectPerceptionAnalysisValue() {
		/*
		 * WebElement perceptionAnalysisValue = driver
		 * .findElement(By.xpath(prop.getProperty(
		 * "opportunities.stagevaluePerceptionAnalysis.xpath")));
		 * perceptionAnalysisValue.click();
		 */

		click(locateElement("xpath", prop.getProperty("opportunities.stagevaluePerceptionAnalysis.xpath")));

		return this;
	}

	public OpportunityPage clickSaveButton() {

		click(locateElement("xpath", prop.getProperty("opportunities.savebtn.xpath")));
		return this;
	}

	public OpportunityPage validateSnackBarMessageWithTitleVerification(String snackBarValue, String labelTextValue)
			throws InterruptedException {

		Assert.assertEquals(snackBarValue,
				getTextMessage(locateElement("xpath", prop.getProperty("opportunities.snackbarmsg.xpath"))));
		Thread.sleep(2000);
		Assert.assertEquals(labelTextValue,
				getTextMessage(locateElement("xpath", prop.getProperty("opportunities.opportunitylabel.xpath"))));

		return this;

	}

	public OpportunityPage validateSnackBarMessage(String snackBarValue) {
		/*
		 * WebElement snackBar = wait.until(ExpectedConditions
		 * .visibilityOfElementLocated(By.xpath(prop.getProperty(
		 * "opportunities.snackbarmsg.xpath")))); String snackBarText =
		 * snackBar.getText();
		 */
		Assert.assertEquals(snackBarValue,
				getTextMessage(locateElement("xpath", prop.getProperty("opportunities.snackbarmsg.xpath"))));
		return this;

	}

	public OpportunityPage validateNoItemsText() {
		/*
		 * WebElement snackBar = wait.until(ExpectedConditions
		 * .visibilityOfElementLocated(By.xpath(prop.getProperty(
		 * "opportunities.snackbarmsg.xpath"))));
		 * System.out.println(snackBar.getText());
		 */

		waitUntilInvisibilityOfElement("xpath", prop.getProperty("opportunities.snackbarmsg.xpath"));
		//waitUntilStalenessof(locateElement("xpath", prop.getProperty("opportunities.snackbarmsg.xpath")));
//		boolean displayed = driver.findElement(By.xpath("//span[text()='" + noItems + "']")).isDisplayed();

		boolean verifyDisplayed = verifyDisplayed(locateElement("xpath", prop.getProperty("common.noitems.xpath")));
		Assert.assertTrue(verifyDisplayed);

		return this;
	}

	public OpportunityPage searchOpportunity(String searchText) throws InterruptedException {
		/*
		 * WebElement searchOpportunity = driver .findElement(By.xpath(prop.getProperty(
		 * "opportunities.searchopportunity.xpath")));
		 * 
		 * searchOpportunity.clear(); searchOpportunity.sendKeys(searchText,
		 * Keys.ENTER);
		 */

		clearAndType(locateElement("xpath", prop.getProperty("opportunities.searchopportunity.xpath")), searchText);
		Thread.sleep(3000);
		return this;
	}

	public OpportunityPage clickOnOpportunityText() throws InterruptedException {
		// driver.findElement(By.xpath(prop.getProperty("opportunities.opportunitytext.xpath"))).click();
		click(locateElement("xpath", prop.getProperty("opportunities.opportunitytext.xpath")));
		Thread.sleep(2000);
		return this;
	}

	public OpportunityPage clickOnFirstSearchElement() {

		waitUntilStalenessof(locateElement("xpath", prop.getProperty("opportunities.firstSearchedElement.xpath")));

		click(locateElement("xpath", prop.getProperty("opportunities.firstSearchedElement.xpath")));

		return this;
	}

	public OpportunityPage clickOnEditButton() {
		// driver.findElement(By.xpath(prop.getProperty("opportunities.editBtn.xpath"))).click();

		click(locateElement("xpath", prop.getProperty("opportunities.editBtn.xpath")));

		return this;
	}

	public OpportunityPage clickDeleteButton() {
		// driver.findElement(By.xpath(prop.getProperty("opportunities.deleteBtn.xpath"))).click();
		click(locateElement("xpath", prop.getProperty("opportunities.deleteBtn.xpath")));
		return this;
	}

	public OpportunityPage acceptDelete() {
		// driver.findElement(By.xpath(prop.getProperty("opportunities.acceptDelete.xpath"))).click();
		click(locateElement("xpath", prop.getProperty("opportunities.acceptDelete.xpath")));

		return this;
	}

	public OpportunityPage clickDeliveryTextBox() throws InterruptedException {
		/*
		 * WebElement deliveryTextbox = driver
		 * .findElement(By.xpath(prop.getProperty("opportunities.deliverytxtbx.xpath")))
		 * ;
		 * 
		 * Thread.sleep(1000); driver.executeScript("arguments[0].click();",
		 * deliveryTextbox);
		 */

		clickUsingJs(locateElement("xpath", prop.getProperty("opportunities.deliverytxtbx.xpath")));
		return this;
	}

	public OpportunityPage selectInprogressDeliveryOption() {
		/*
		 * WebElement inProgress = driver .findElement(By.xpath(prop.getProperty(
		 * "opportunities.inprogressDeliveryOption.xpath")));
		 * driver.executeScript("arguments[0].click();", inProgress);
		 */
		clickUsingJs(locateElement("xpath", prop.getProperty("opportunities.inprogressDeliveryOption.xpath")));

		return this;

	}

	public OpportunityPage enterDescription(String enterDescription) {
		/*
		 * driver.findElement(By.xpath(prop.getProperty(
		 * "opportunities.description.xpath"))).clear();
		 * driver.findElement(By.xpath(prop.getProperty(
		 * "opportunities.description.xpath"))).sendKeys(enterDescription);
		 */

		clearAndType(locateElement("xpath", prop.getProperty("opportunities.description.xpath")), enterDescription);

		return this;

	}

	public OpportunityPage validateStageText(String verifyStageText) {
		waitUntilStalenessof(locateElement("xpath", prop.getProperty("opportunities.firstSearchedElement.xpath")));

		/*
		 * String getText = driver.findElement(By.xpath(prop.getProperty(
		 * "opportunities.stagetextresults.xpath"))) .getText();
		 */
		
		Assert.assertEquals(verifyStageText, getTextMessage(locateElement("xpath", prop.getProperty("opportunities.stagetextresults.xpath"))));
		return this;
	}

	public OpportunityPage clickRefreshButton() {

		//waitUntilStalenessof(locateElement("xpath", prop.getProperty("opportunities.firstSearchedElement.xpath")));

		click(locateElement("xpath", prop.getProperty("opportunities.refreshbtn.xpath")));
		// clickUsingJs(locateElement("xpath",
		// prop.getProperty("opportunities.refreshbtn.xpath")));
		return this;

	}

}
