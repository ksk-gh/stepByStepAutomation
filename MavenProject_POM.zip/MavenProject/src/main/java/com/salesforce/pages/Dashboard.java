package com.salesforce.pages;

import com.salesforce.base.ProjectSpecificMethods;

public class Dashboard extends ProjectSpecificMethods{

	
public Dashboard clickNewDashboard() {
	
	click(locateElement("xpath", prop.getProperty("dashboard.new.xpath")));
	return this;
}

public Dashboard enterName(String dashboardName) {
	
	type(locateElement("id", prop.getProperty("dashboard.name.id")), dashboardName);
	return this;
}
	
}
