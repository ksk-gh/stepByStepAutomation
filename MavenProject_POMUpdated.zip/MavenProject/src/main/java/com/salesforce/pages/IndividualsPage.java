package com.salesforce.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.salesforce.base.ProjectSpecificMethods;

public class IndividualsPage extends ProjectSpecificMethods {

	public IndividualsPage clickDownArrow() {
		// driver.findElement(By.xpath(prop.getProperty("individuals.individualsdownarrow.xpath"))).click();
		click(locateElement("xpath", prop.getProperty("individuals.individualsdownarrow.xpath")));
		return this;
	}

	public IndividualsPage clickNewIndividualLink() {
		/*
		 * WebElement newIndividualLink = driver
		 * .findElement(By.xpath(prop.getProperty("individuals.newindividuals.xpath")));
		 * driver.executeScript("arguments[0].click();", newIndividualLink);
		 */

		clickUsingJs(locateElement("xpath", prop.getProperty("individuals.newindividuals.xpath")));
		return this;
	}

	public IndividualsPage enterlastName(String lName) {
		// driver.findElement(By.xpath(prop.getProperty("individuals.lastname.xpath"))).sendKeys(lName);

		type(locateElement("xpath", prop.getProperty("individuals.lastname.xpath")), lName);
		return this;
	}

	public IndividualsPage clickSaveButton() {
		// driver.findElement(By.xpath(prop.getProperty("individuals.savebtn.xpath"))).click();

		click(locateElement("xpath", prop.getProperty("individuals.savebtn.xpath")));
		return this;
	}

	public IndividualsPage validateSnackBarMsg(String toastMessage) {

		/*
		 * WebElement snackBar = wait.until(ExpectedConditions
		 * .visibilityOfElementLocated(By.xpath(prop.getProperty(
		 * "individuals.snackbar.xpath")))); String snackMessage = snackBar.getText();
		 */

		waitUntilElementLocated("xpath", prop.getProperty("individuals.snackbar.xpath"));
		Assert.assertEquals(toastMessage,
				getTextMessage(locateElement("xpath", prop.getProperty("individuals.snackbar.xpath"))));
		return this;
	}

	public IndividualsPage clickIndividualsMenu() {
		/*
		 * WebElement individualsMenuLink = driver
		 * .findElement(By.xpath(prop.getProperty("individuals.individualsmenu.xpath")))
		 * ; driver.executeScript("arguments[0].click();", individualsMenuLink);
		 */

		clickUsingJs(locateElement("xpath", prop.getProperty("individuals.individualsmenu.xpath")));

		return this;
	}

	public IndividualsPage enterSearchText(String searchText) throws InterruptedException {
		// driver.findElement(By.xpath(prop.getProperty("individuals.searhbox.xpath"))).sendKeys(searchText);

		// type(locateElement("xpath", prop.getProperty("individuals.searhbox.xpath")),
		// searchText);
		clearAndTypeWithEnter(locateElement("xpath", prop.getProperty("individuals.searhbox.xpath")), searchText);
		Thread.sleep(2000);
		return this;
	}

	public IndividualsPage clickRecentlyViewed() throws InterruptedException {
		// driver.findElement(By.xpath(prop.getProperty("individuals.recentlyviewed.xpath"))).click();

		click(locateElement("xpath", prop.getProperty("individuals.recentlyviewed.xpath")));
		Thread.sleep(2000);
		return this;
	}

	public IndividualsPage selectFirstElement() throws InterruptedException {
		/*
		 * WebElement clickDropDown =
		 * driver.findElement(By.xpath(prop.getProperty("individuals.firstelement.xpath"
		 * ))); driver.executeScript("arguments[0].click();", clickDropDown);
		 */
		waitUntilStalenessof(locateElement("xpath", prop.getProperty("individuals.firstelement.xpath")));
		clickUsingJs(locateElement("xpath", prop.getProperty("individuals.firstelement.xpath")));

		Thread.sleep(2000);
		return this;
	}

	public IndividualsPage clickEditButton() {
		/*
		 * WebElement editButton =
		 * driver.findElement(By.xpath(prop.getProperty("individuals.editbutton.xpath"))
		 * ); editButton.click();
		 */
		click(locateElement("xpath", prop.getProperty("individuals.editbutton.xpath")));

		return this;
	}

	public IndividualsPage clickSalutationTextBox() {
		// driver.findElement(By.xpath(prop.getProperty("individuals.salutation.xpath"))).click();
		click(locateElement("xpath", prop.getProperty("individuals.salutation.xpath")));
		return this;
	}

	public IndividualsPage selectSalutationOption() {
		String salutation = "Mr.";
		WebElement salutationOption = driver.findElement(By.xpath("//a[@title='" + salutation + "']"));
		click(salutationOption);
		return this;
	}

	public IndividualsPage enterFirstName(String firstName) {
		/*
		 * WebElement firstNameTextBox =
		 * driver.findElement(By.xpath(prop.getProperty("individuals.firstname.xpath")))
		 * ; firstNameTextBox.clear(); firstNameTextBox.sendKeys(firstName);
		 */
		type(locateElement("xpath", prop.getProperty("individuals.firstname.xpath")), firstName);

		return this;
	}

	public IndividualsPage clickDeleteButton() {
		// driver.findElement(By.xpath(prop.getProperty("individuals.deletebutton.xpath"))).click();

		// click(locateElement("xpath",
		// prop.getProperty("individuals.deletebutton.xpath")));
		click(locateElement("xpath", prop.getProperty("individuals.deletebutton.xpath")));

		return this;
	}

	public IndividualsPage acceptDelete() throws InterruptedException {
		// driver.findElement(By.xpath(prop.getProperty("individuals.acceptdelete.xpath"))).click();

		waitUntilElementLocated("xpath", prop.getProperty("individuals.acceptdelete.xpath"));
		click(locateElement("xpath", prop.getProperty("individuals.acceptdelete.xpath")));
		// clickUsingJs(locateElement("xpath",
		// prop.getProperty("individuals.acceptdelete.xpath")));
		Thread.sleep(5000);
		return this;
	}

	public IndividualsPage noItemDisplayed() {

		/*
		 * String Message = "No items to display."; WebElement noItem = wait.until(
		 * ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+
		 * Message+"']")));
		 * 
		 * boolean displayed = noItem.isDisplayed(); Assert.assertTrue(displayed);
		 */

		// waitUntilInvisibilityOfElement("xpath",
		// prop.getProperty("opportunities.snackbarmsg.xpath"));
		boolean isDisplayed = verifyDisplayed(locateElement("xpath", prop.getProperty("common.noitems.xpath")));
		Assert.assertTrue(isDisplayed);
		return this;
	}

	public IndividualsPage validateLastNameErrormessage(String errorText) {
		/*
		 * String getErrorMessage = driver.findElement(By.xpath(prop.getProperty(
		 * "individuals.lastnameerrormsg.xpath"))) .getText();
		 * 
		 * System.out.println(getErrorMessage); Assert.assertEquals(errorText,
		 * getErrorMessage);
		 */
		Assert.assertEquals(errorText,
				getTextMessage(locateElement("xpath", prop.getProperty("individuals.lastnameerrormsg.xpath"))));

		return this;
	}

	public IndividualsPage clickRefreshButton() {
		/*
		 * WebElement refreshButton =
		 * driver.findElement(By.xpath(prop.getProperty("accounts.refreshbtn.xpath")));
		 * driver.executeScript("arguments[0].click();", refreshButton);
		 */
		// refreshButton.click();
		click(locateElement("xpath", prop.getProperty("individuals.refreshbtn.xpath")));
		// clickUsingJs(locateElement("xpath",
		// prop.getProperty("accounts.refreshbtn.xpath")));
		return this;

	}
}
